function selecionarPerfil(perfil) {
    switch (perfil) {
        case 'usuario':
            window.location.href = 'loginusuario.html'; 
            break;
        case 'gerente':
            window.location.href = 'logingerente.html'; 
            break;
        case 'funcionario':
            window.location.href = 'loginfuncionario.html'; 
            break;
        default:
            alert('Perfil não reconhecido.');
    }
}