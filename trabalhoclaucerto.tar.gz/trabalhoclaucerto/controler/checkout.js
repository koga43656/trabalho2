let reservas = JSON.parse(localStorage.getItem("reservas")) || [];

        function carregarHospedesParaCheckout() {
            const tabela = document.getElementById("listaCheckout").getElementsByTagName("tbody")[0];
            tabela.innerHTML = "";
            reservas.forEach((reserva, index) => {
                const row = tabela.insertRow();
                row.insertCell(0).innerText = reserva.nomeUsuario;
                row.insertCell(1).innerText = reserva.dataCheckin;
                row.insertCell(2).innerText = reserva.dataCheckout;

                
                const valorTotal = reserva.valorTotal.toFixed(2);
                row.insertCell(3).innerText = `R$ ${valorTotal}`;

                const acaoCell = row.insertCell(4);
                const botaoVerConta = document.createElement("button");
                botaoVerConta.innerText = "Ver Conta";
                botaoVerConta.onclick = () => {
                  
                    window.location.href = `contas.html?nomeHospede=${encodeURIComponent(reserva.nomeUsuario)}`;
                };
                acaoCell.appendChild(botaoVerConta);
            });
        }

        function encerrarEstadia() {
            const nomeHospede = document.getElementById("nomeHospedeCheckout").value.trim();

            if (!nomeHospede) {
                alert("Por favor, insira o nome do hóspede.");
                return;
            }

          
            const index = reservas.findIndex(reserva => reserva.nomeUsuario === nomeHospede);
            if (index === -1) {
                alert("Hóspede não encontrado para check-out.");
                return;
            }

            
            reservas.splice(index, 1);
            localStorage.setItem("reservas", JSON.stringify(reservas));

            
            carregarHospedesParaCheckout();

            alert("Estadia encerrada com sucesso!");

            
            localStorage.setItem("totalConta", "0");
        }

        window.onload = carregarHospedesParaCheckout;