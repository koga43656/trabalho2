function carregarReservas() {
    return JSON.parse(localStorage.getItem("reservas")) || [];
}


function fazerLoginHospede(event) {
    event.preventDefault();

    const nome = document.getElementById("nomeHospede").value;
    const senha = document.getElementById("senhaHospede").value;
    const reservas = carregarReservas();

   
    const reserva = reservas.find(r => r.nomeUsuario === nome && r.senhaUsuario === senha);

    if (reserva) {
        alert("Login bem-sucedido! Bem-vindo, " + reserva.nomeUsuario);
        window.location.href = "indexhospede.html"; 
    } else {
        alert("Nome ou senha inválidos. Tente novamente.");
    }
}


function irParaCadastroHospede() {
    window.location.href = "reservausuario.html";
}