function carregarUsuarios() {
    return JSON.parse(localStorage.getItem("usuarios")) || [];
}

function salvarUsuarios(usuarios) {
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
}

function cadastrarUsuario(event) {
    event.preventDefault();

    const nome = document.getElementById("nomeUsuario").value;
    const email = document.getElementById("emailUsuario").value;
    const senha = document.getElementById("senhaUsuario").value;
    const endereco = document.getElementById("enderecoUsuario").value;

    const usuarios = carregarUsuarios();

   
    const nomeExistente = usuarios.some(usuario => usuario.nome === nome);
    if (nomeExistente) {
        alert("Já existe um usuário com este nome. Escolha outro nome.");
        return;
    }

   
    const novoId = usuarios.length > 0 ? Math.max(...usuarios.map(usuario => usuario.id)) + 1 : 0;

    const novoUsuario = {
        id: novoId, 
        nome: nome,
        email: email,
        senha: senha,
        endereco: endereco
    };

  
    usuarios.push(novoUsuario);
    salvarUsuarios(usuarios);

    alert("Usuário cadastrado com sucesso!");
    window.location.href = "loginusuario.html";
    document.getElementById("formCadastro").reset();
}
