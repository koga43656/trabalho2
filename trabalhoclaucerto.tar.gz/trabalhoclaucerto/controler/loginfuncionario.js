function loginFuncionario(event) {
    event.preventDefault();

    const nome = document.getElementById("nomeFuncionario").value;
    const senha = document.getElementById("senhaFuncionario").value;


    const funcionarios = JSON.parse(localStorage.getItem("funcionarios")) || [];


    const funcionario = funcionarios.find(f => f.nome === nome && f.senha === senha);

    if (funcionario) {
        alert("Login bem-sucedido! Bem-vindo, " + funcionario.nome);
        window.location.href = "indexfuncionario.html";
    } else {
        alert("Nome ou senha inválidos. Tente novamente.");
    }
}