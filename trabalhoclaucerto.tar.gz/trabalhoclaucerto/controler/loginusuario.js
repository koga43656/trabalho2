function carregarUsuarios() {
    return JSON.parse(localStorage.getItem("usuarios")) || [];
}

function fazerLogin(event) {
    event.preventDefault();

    const nome = document.getElementById("nomeUsuario").value;
    const senha = document.getElementById("senhaUsuario").value;
    const usuarios = carregarUsuarios();


    const usuario = usuarios.find(u => u.nome === nome && u.senha === senha);

    if (usuario) {
        alert("Login bem-sucedido! Bem-vindo, " + usuario.nome);
        window.location.href = "indexusuario.html";
    } else {
        alert("Nome ou senha inválidos. Tente novamente.");
    }
}

function irParaCadastro() {
    window.location.href = "cadastro.html";
}