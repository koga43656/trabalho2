let produtosFrigobar = JSON.parse(localStorage.getItem("produtosFrigobar")) || [];

       
function adicionarProduto() {
    const nome = document.getElementById("nomeProduto").value;
    const id = document.getElementById("idProduto").value;
    const preco = parseFloat(document.getElementById("precoProduto").value);

   
    if (!nome || !id || isNaN(preco)) {
        alert("Por favor, preencha todos os campos corretamente!");
        return;
    }

  
    const produto = {id, nome, preco};
    produtosFrigobar.push(produto);

    localStorage.setItem("produtosFrigobar", JSON.stringify(produtosFrigobar));
    atualizarTabelaFrigobar();
    document.getElementById("formFrigobar").reset(); 
}


function atualizarTabelaFrigobar() {
    const tabela = document.getElementById("listaFrigobar").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";

    produtosFrigobar.forEach((produto, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = produto.id;
        row.insertCell(1).innerText = produto.nome;
        row.insertCell(2).innerText = `R$ ${produto.preco.toFixed(2)}`;

       
        const acaoCell = row.insertCell(3);
        const botaoRemover = document.createElement("button");
        botaoRemover.innerText = "Remover";
        botaoRemover.onclick = () => removerProduto(index);
        acaoCell.appendChild(botaoRemover);
    });
}


function removerProduto(index) {
    produtosFrigobar.splice(index, 1); 
    localStorage.setItem("produtosFrigobar", JSON.stringify(produtosFrigobar)); 
    atualizarTabelaFrigobar();
}

window.onload = atualizarTabelaFrigobar;