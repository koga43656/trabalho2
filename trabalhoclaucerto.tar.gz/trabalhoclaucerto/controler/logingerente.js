const gerentesIniciais = [
    {id: 1, nome: "koga", senha: "sddsmaryclare"},
    {id: 2, nome: "mu borges", senha: "sophia777"},
    {id: 3, nome: "vini banos", senha: "estadolover"},
    {id: 4, nome: "mu santos", senha: "sociologoraiamsantos"}
];


function inicializarGerentes() {
    const gerentes = JSON.parse(localStorage.getItem("gerentes")) || [];
    if (gerentes.length === 0) {
        localStorage.setItem("gerentes", JSON.stringify(gerentesIniciais));
    }
}


function loginGerente(event) {
    event.preventDefault();
    const nome = document.getElementById("nomeGerente").value;
    const senha = document.getElementById("senhaGerente").value;
    
    const gerentes = JSON.parse(localStorage.getItem("gerentes")) || [];

 
    const gerente = gerentes.find(g => g.nome === nome && g.senha === senha);

    if (gerente) {
        alert(`Bem-vindo, ${gerente.nome}! (ID: ${gerente.id})`);
       
        window.location.href = "ident.html";
    } else {
        alert("Nome ou senha incorretos.");
    }
}


window.onload = inicializarGerentes;