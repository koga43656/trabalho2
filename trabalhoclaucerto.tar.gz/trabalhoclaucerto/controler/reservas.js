let reservas = JSON.parse(localStorage.getItem("reservas")) || [];

function adicionarReserva() {
const nomeUsuario = document.getElementById("nomeUsuarioReserva").value.trim();
const idUsuario = parseInt(document.getElementById("idUsuarioReserva").value, 10);
const emailUsuario = document.getElementById("emailUsuarioReserva").value.trim();
const tipoQuarto = document.getElementById("tipoQuarto").value;
const dataCheckin = document.getElementById("dataCheckin").value;
const dataCheckout = document.getElementById("dataCheckout").value;


if (!nomeUsuario || isNaN(idUsuario) || !emailUsuario || !tipoQuarto || !dataCheckin || !dataCheckout) {
alert("Por favor, preencha todos os campos corretamente!");
return;
}


const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
const usuarioEncontrado = usuarios.find(user => user.nome === nomeUsuario);


if (!usuarioEncontrado) {
alert("Usuário não encontrado. Por favor, cadastre-se primeiro.");
return;
}

const senhaUsuario = usuarioEncontrado.senha;


const nomeExistente = reservas.some(reserva => reserva.nomeUsuario === nomeUsuario);
if (nomeExistente) {
alert("Já existe uma reserva com este nome de usuário. Por favor, use um nome diferente.");
return;
}


const checkinDate = new Date(dataCheckin);
const checkoutDate = new Date(dataCheckout);
const diasEstadia = (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24);

if (diasEstadia <= 0) {
alert("A data de check-out deve ser posterior à data de check-in.");
return;
}


const valorDiaria = parseFloat(tipoQuarto);
const valorTotal = valorDiaria * diasEstadia;


const reserva = {
nomeUsuario: nomeUsuario,
idUsuario: idUsuario,
emailUsuario: emailUsuario,
senhaUsuario: senhaUsuario, 
tipoQuarto: tipoQuarto,
dataCheckin: dataCheckin,
dataCheckout: dataCheckout,
valorTotal: valorTotal
};


reservas.push(reserva);
localStorage.setItem("reservas", JSON.stringify(reservas));
atualizarTabelaReservas();
document.getElementById("formReserva").reset();
}

function atualizarTabelaReservas() {
    const tabela = document.getElementById("listaReservas").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";

    reservas.forEach((reserva, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = reserva.nomeUsuario;
        row.insertCell(1).innerText = reserva.idUsuario;
        row.insertCell(2).innerText = reserva.emailUsuario;
        row.insertCell(3).innerText = reserva.tipoQuarto;
        row.insertCell(4).innerText = reserva.dataCheckin;
        row.insertCell(5).innerText = reserva.dataCheckout;
        row.insertCell(6).innerText = `R$ ${reserva.valorTotal.toFixed(2).replace('.', ',')}`;
        const acaoCell = row.insertCell(7);
        const botaoRemover = document.createElement("button");
        botaoRemover.innerText = "Remover";
        botaoRemover.onclick = () => removerReserva(index);
        acaoCell.appendChild(botaoRemover);
    });
}

function removerReserva(index) {
    reservas.splice(index, 1);
    localStorage.setItem("reservas", JSON.stringify(reservas));
    atualizarTabelaReservas();
}

window.onload = atualizarTabelaReservas;