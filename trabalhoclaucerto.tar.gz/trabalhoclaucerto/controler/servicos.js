let servicos = JSON.parse(localStorage.getItem("servicos")) || [];

     
function adicionarServico() {
    const nome = document.getElementById("nomeServico").value;
    const id = document.getElementById("idServico").value;
    const preco = parseFloat(document.getElementById("precoServico").value);

  
    if (!nome || !id || isNaN(preco)) {
        alert("Por favor, preencha todos os campos corretamente!");
        return;
    }

    
    const servico = {id, nome, preco};
    servicos.push(servico);

  
    localStorage.setItem("servicos", JSON.stringify(servicos));
    atualizarTabelaServicos();
    document.getElementById("formServico").reset();
}


function atualizarTabelaServicos() {
    const tabela = document.getElementById("listaServicos").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";

    servicos.forEach((servico, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = servico.id;
        row.insertCell(1).innerText = servico.nome;
        row.insertCell(2).innerText = `R$ ${servico.preco.toFixed(2)}`;

     
        const acaoCell = row.insertCell(3);
        const botaoRemover = document.createElement("button");
        botaoRemover.innerText = "Remover";
        botaoRemover.onclick = () => removerServico(index);
        acaoCell.appendChild(botaoRemover);
    });
}


function removerServico(index) {
    servicos.splice(index, 1); 
    localStorage.setItem("servicos", JSON.stringify(servicos));
    atualizarTabelaServicos();
}


window.onload = atualizarTabelaServicos;