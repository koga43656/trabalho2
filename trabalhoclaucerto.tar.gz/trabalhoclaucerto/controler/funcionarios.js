function carregarFuncionarios() {
    return JSON.parse(localStorage.getItem("funcionarios")) || [];
}


function salvarFuncionarios() {
    localStorage.setItem("funcionarios", JSON.stringify(funcionarios));
}

let funcionarios = carregarFuncionarios();

function registrarFuncionario(event) {
    event.preventDefault();
    const id = document.getElementById("idFuncionario").value;
    const nome = document.getElementById("nomeFuncionario").value;
    const cargo = document.getElementById("cargoFuncionario").value;
    const senha = document.getElementById("senhaFuncionario").value;

   
    if (!id || !nome || !cargo || !senha) {
        alert("Por favor, preencha todos os campos corretamente!");
        return;
    }

    
    if (funcionarios.find(f => f.id == id)) {
        alert("Este ID já está cadastrado. Por favor, escolha outro ID.");
        return;
    }

  
    const funcionario = {
        id: id,
        nome: nome,
        cargo: cargo,
        senha: senha 
    };

   
    funcionarios.push(funcionario);
    salvarFuncionarios();

 
    atualizarTabelaFuncionarios();

 
    document.getElementById("formFuncionario").reset();
}


function atualizarTabelaFuncionarios() {
    const tabela = document.getElementById("listaFuncionarios").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";

    funcionarios.forEach((funcionario, index) => {
        const row = tabela.insertRow();

       
        row.insertCell(0).innerText = funcionario.id; 
        row.insertCell(1).innerText = funcionario.nome; 
        row.insertCell(2).innerText = funcionario.cargo; 

      
        const acaoCell = row.insertCell(3);
        const botaoRemover = document.createElement("button");
        botaoRemover.innerText = "Remover";
        botaoRemover.onclick = () => removerFuncionario(index);
        acaoCell.appendChild(botaoRemover);
    });
}


function removerFuncionario(index) {
    if (confirm("Você tem certeza que deseja remover este funcionário?")) {
        funcionarios.splice(index, 1); 
        salvarFuncionarios(); 
        atualizarTabelaFuncionarios();
    }
}


window.onload = atualizarTabelaFuncionarios;