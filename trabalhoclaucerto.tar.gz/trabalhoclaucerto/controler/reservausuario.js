function carregarUsuarios() {
    return JSON.parse(localStorage.getItem("usuarios")) || [];
}


function confirmarCadastro() {
    const confirmacao = confirm("Tem certeza de que deseja fazer o cadastro?");
    if (confirmacao) {
        verificarSenhaUsuario();
    }
}


function verificarSenhaUsuario() {
    const nomeUsuario = document.getElementById("nomeUsuario").value;
    const senhaUsuario = document.getElementById("senhaUsuario").value;
    const usuarios = carregarUsuarios();

    const usuarioEncontrado = usuarios.find(user => user.nome === nomeUsuario);

    if (usuarioEncontrado && usuarioEncontrado.senha === senhaUsuario) {
        adicionarReservaQuarto(usuarioEncontrado);
    } else {
        alert("Nome de usuário ou senha incorretos!");
    }
}

function adicionarReservaQuarto(usuario) {
const tipoQuarto = document.getElementById("tipoQuarto").value;
const dataCheckin = document.getElementById("dataCheckinQuarto").value;
const dataCheckout = document.getElementById("dataCheckoutQuarto").value;
const emailUsuario = document.getElementById("emailUsuario").value; 
const enderecoUsuario = document.getElementById("enderecoUsuario").value; 

if (!tipoQuarto || !dataCheckin || !dataCheckout) {
alert("Por favor, preencha todos os campos corretamente!");
return;
}

const checkinDate = new Date(dataCheckin);
const checkoutDate = new Date(dataCheckout);
const diasEstadia = (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24);

if (diasEstadia <= 0) {
alert("A data de check-out deve ser posterior à data de check-in.");
return;
}

const valorDiaria = parseFloat(tipoQuarto); 
const valorTotal = valorDiaria * diasEstadia; 

document.getElementById("valorTotalReserva").innerText = valorTotal.toFixed(2).replace(".", ",");


const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
const usuarioEncontrado = usuarios.find(u => u.nome === usuario.nome);

if (!usuarioEncontrado) {
alert("Usuário não encontrado. Por favor, cadastre-se primeiro.");
return;
}

const senhaUsuario = usuarioEncontrado.senha;


const reserva = {
nomeUsuario: usuario.nome,
idUsuario: usuario.id,
emailUsuario, 
enderecoUsuario, 
senhaUsuario,
tipoQuarto,
dataCheckin,
dataCheckout,
valorTotal
};

let reservas = JSON.parse(localStorage.getItem("reservas")) || [];
reservas.push(reserva);
localStorage.setItem("reservas", JSON.stringify(reservas));

alert("Reserva cadastrada com sucesso!");
document.getElementById("formReservaQuarto").reset();
window.location.href = "indexhospede.html"; 
}
