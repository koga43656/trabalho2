function carregarGerentes() {
    return JSON.parse(localStorage.getItem("gerentes")) || [];
}


function salvarGerentes(gerentes) {
    localStorage.setItem("gerentes", JSON.stringify(gerentes));
}


function adicionarGerente(event) {
    event.preventDefault();

    const id = Number(document.getElementById("id").value);
    const nome = document.getElementById("nomeGerente").value;
    const senha = document.getElementById("senhaGerente").value;

    if (!id || !nome || !senha) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    const gerentes = carregarGerentes();

  
    const gerenteExistente = gerentes.find(g => g.id == id || g.nome === nome);
    if (gerenteExistente) {
        alert("Este ID ou nome de gerente já existe. Escolha outro.");
        return;
    }

  
    gerentes.push({id, nome, senha});
    salvarGerentes(gerentes);
    atualizarTabelaGerentes();
    document.getElementById("formGerente").reset();
}


function removerGerente(index) {
    if (confirm("Você tem certeza que deseja remover este gerente?")) {
        const gerentes = carregarGerentes();
        gerentes.splice(index, 1);
        salvarGerentes(gerentes);
        atualizarTabelaGerentes();
    }
}


function atualizarTabelaGerentes() {
    const tabela = document.getElementById("listaGerentes").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";
    const gerentes = carregarGerentes();

    gerentes.forEach((gerente, index) => {
const row = tabela.insertRow();
row.insertCell(0).innerText = gerente.id ? gerente.id : "ID não encontrado"; 
row.insertCell(1).innerText = gerente.nome; 
const acaoCell = row.insertCell(2);
const botaoRemover = document.createElement("button");
botaoRemover.innerText = "Remover";
botaoRemover.onclick = () => removerGerente(index);
acaoCell.appendChild(botaoRemover);
});

}

window.onload = atualizarTabelaGerentes;