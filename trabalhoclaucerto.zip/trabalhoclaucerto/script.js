function carregarUsuarios() {
    return JSON.parse(localStorage.getItem("usuarios")) || [];
}

function salvarUsuarios(usuarios) {
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
}

function cadastrarUsuario(event) {
    event.preventDefault();

    const nome = document.getElementById("nomeUsuario").value;
    const email = document.getElementById("emailUsuario").value;
    const senha = document.getElementById("senhaUsuario").value;
    const endereco = document.getElementById("enderecoUsuario").value;

    const usuarios = carregarUsuarios();

   
    const nomeExistente = usuarios.some(usuario => usuario.nome === nome);
    if (nomeExistente) {
        alert("Já existe um usuário com este nome. Escolha outro nome.");
        return;
    }

   
    const novoId = usuarios.length > 0 ? Math.max(...usuarios.map(usuario => usuario.id)) + 1 : 0;

    const novoUsuario = {
        id: novoId, 
        nome: nome,
        email: email,
        senha: senha,
        endereco: endereco
    };

  
    usuarios.push(novoUsuario);
    salvarUsuarios(usuarios);

    alert("Usuário cadastrado com sucesso!");
    document.getElementById("formCadastro").reset();
}

function fazerLogin(event) {
    event.preventDefault();

    const nome = document.getElementById("nomeUsuario").value;
    const senha = document.getElementById("senhaUsuario").value;
    const usuarios = carregarUsuarios();


    const usuario = usuarios.find(u => u.nome === nome && u.senha === senha);

    if (usuario) {
        alert("Login bem-sucedido! Bem-vindo, " + usuario.nome);
        window.location.href = "indexusuario.html";
    } else {
        alert("Nome ou senha inválidos. Tente novamente.");
    }
}

function irParaCadastro() {
    window.location.href = "cadastro.html";
}

const gerentesIniciais = [
    {id: 1, nome: "koga", senha: "sddsmaryclare"},
    {id: 2, nome: "mu borges", senha: "sophia777"},
    {id: 3, nome: "vini banos", senha: "estadolover"},
    {id: 4, nome: "mu santos", senha: "crecslover"}
];


function inicializarGerentes() {
    const gerentes = JSON.parse(localStorage.getItem("gerentes")) || [];
    if (gerentes.length === 0) {
        localStorage.setItem("gerentes", JSON.stringify(gerentesIniciais));
    }
}


function loginGerente(event) {
    event.preventDefault();
    const nome = document.getElementById("nomeGerente").value;
    const senha = document.getElementById("senhaGerente").value;
    
    const gerentes = JSON.parse(localStorage.getItem("gerentes")) || [];

 
    const gerente = gerentes.find(g => g.nome === nome && g.senha === senha);

    if (gerente) {
        alert(`Bem-vindo, ${gerente.nome}! (ID: ${gerente.id})`);
       
        window.location.href = "ident.html";
    } else {
        alert("Nome ou senha incorretos.");
    }
}


window.onload = inicializarGerentes;

function carregarReservas() {
    return JSON.parse(localStorage.getItem("reservas")) || [];
}


function fazerLoginHospede(event) {
    event.preventDefault();

    const nome = document.getElementById("nomeHospede").value;
    const senha = document.getElementById("senhaHospede").value;
    const reservas = carregarReservas();

   
    const reserva = reservas.find(r => r.nomeUsuario === nome && r.senhaUsuario === senha);

    if (reserva) {
        alert("Login bem-sucedido! Bem-vindo, " + reserva.nomeUsuario);
        window.location.href = "indexhospede.html"; 
    } else {
        alert("Nome ou senha inválidos. Tente novamente.");
    }
}


function irParaCadastroHospede() {
    window.location.href = "reservausuario.html";
}
function loginFuncionario(event) {
    event.preventDefault();

    const nome = document.getElementById("nomeFuncionario").value;
    const senha = document.getElementById("senhaFuncionario").value;


    const funcionarios = JSON.parse(localStorage.getItem("funcionarios")) || [];


    const funcionario = funcionarios.find(f => f.nome === nome && f.senha === senha);

    if (funcionario) {
        alert("Login bem-sucedido! Bem-vindo, " + funcionario.nome);
        window.location.href = "indexfuncionario.html";
    } else {
        alert("Nome ou senha inválidos. Tente novamente.");
    }
}

let reservas = JSON.parse(localStorage.getItem("reservas")) || [];

function adicionarReserva() {
    const nomeUsuario = document.getElementById("nomeUsuarioReserva").value.trim();
    const idUsuario = parseInt(document.getElementById("idUsuarioReserva").value, 10);
    const emailUsuario = document.getElementById("emailUsuarioReserva").value.trim();
    const tipoQuarto = document.getElementById("tipoQuarto").value;
    const dataCheckin = document.getElementById("dataCheckin").value;
    const dataCheckout = document.getElementById("dataCheckout").value;

    if (!nomeUsuario || isNaN(idUsuario) || !emailUsuario || !tipoQuarto || !dataCheckin || !dataCheckout) {
        alert("Por favor, preencha todos os campos corretamente!");
        return;
    }

   
    const nomeExistente = reservas.some(reserva => reserva.nomeUsuario === nomeUsuario);
    if (nomeExistente) {
        alert("Já existe uma reserva com este nome de usuário. Por favor, use um nome diferente.");
        return;
    }

    const checkinDate = new Date(dataCheckin);
    const checkoutDate = new Date(dataCheckout);
    const diasEstadia = (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24);

    if (diasEstadia <= 0) {
        alert("A data de check-out deve ser posterior à data de check-in.");
        return;
    }

    const valorDiaria = parseFloat(tipoQuarto);
    const valorTotal = valorDiaria * diasEstadia;

    const reserva = {
        nomeUsuario: nomeUsuario,
        idUsuario: idUsuario,
        emailUsuario: emailUsuario,
        tipoQuarto: tipoQuarto,
        dataCheckin: dataCheckin,
        dataCheckout: dataCheckout,
        valorTotal: valorTotal
    };

    reservas.push(reserva);
    localStorage.setItem("reservas", JSON.stringify(reservas));
    atualizarTabelaReservas();
    document.getElementById("formReserva").reset();
}

function atualizarTabelaReservas() {
    const tabela = document.getElementById("listaReservas").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";

    reservas.forEach((reserva, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = reserva.nomeUsuario;
        row.insertCell(1).innerText = reserva.idUsuario;
        row.insertCell(2).innerText = reserva.emailUsuario;
        row.insertCell(3).innerText = reserva.tipoQuarto;
        row.insertCell(4).innerText = reserva.dataCheckin;
        row.insertCell(5).innerText = reserva.dataCheckout;
        row.insertCell(6).innerText = `R$ ${reserva.valorTotal.toFixed(2).replace('.', ',')}`;
        const acaoCell = row.insertCell(7);
        const botaoRemover = document.createElement("button");
        botaoRemover.innerText = "Remover";
        botaoRemover.onclick = () => removerReserva(index);
        acaoCell.appendChild(botaoRemover);
    });
}

function removerReserva(index) {
    reservas.splice(index, 1);
    localStorage.setItem("reservas", JSON.stringify(reservas));
    atualizarTabelaReservas();
}

window.onload = atualizarTabelaReservas;


function atualizarTabelaUsuarios() {
    const usuarios = carregarUsuarios();
    const tabelaBody = document.getElementById("listaUsuarios").getElementsByTagName("tbody")[0];
    tabelaBody.innerHTML = ""; 

    usuarios.forEach((usuario, index) => {
        const row = tabelaBody.insertRow();

       
        row.insertCell(0).innerText = usuario.nome;   
        row.insertCell(1).innerText = usuario.email;  
        row.insertCell(2).innerText = usuario.id;    
        row.insertCell(3).innerText = usuario.endereco; 

       
        const acaoCell = row.insertCell(4);
        const botaoRemover = document.createElement("button");
        botaoRemover.innerText = "Remover";
        botaoRemover.onclick = () => removerUsuario(index);
        acaoCell.appendChild(botaoRemover);
    });
}

function removerUsuario(index) {
    if (confirm("Você tem certeza que deseja remover este usuário?")) {
        const usuarios = carregarUsuarios();
        usuarios.splice(index, 1); 
        localStorage.setItem("usuarios", JSON.stringify(usuarios));
        atualizarTabelaUsuarios();
    }
}

window.onload = atualizarTabelaUsuarios;
function carregarUsuarios() {
    return JSON.parse(localStorage.getItem("usuarios")) || [];
}


function confirmarCadastro() {
    const confirmacao = confirm("Tem certeza de que deseja fazer o cadastro?");
    if (confirmacao) {
        verificarSenhaUsuario();
    }
}


function verificarSenhaUsuario() {
    const nomeUsuario = document.getElementById("nomeUsuario").value;
    const senhaUsuario = document.getElementById("senhaUsuario").value;
    const usuarios = carregarUsuarios();

    const usuarioEncontrado = usuarios.find(user => user.nome === nomeUsuario);

    if (usuarioEncontrado && usuarioEncontrado.senha === senhaUsuario) {
        adicionarReservaQuarto(usuarioEncontrado);
    } else {
        alert("Nome de usuário ou senha incorretos!");
    }
}

function adicionarReservaQuarto(usuario) {
    const tipoQuarto = document.getElementById("tipoQuarto").value;
    const dataCheckin = document.getElementById("dataCheckinQuarto").value;
    const dataCheckout = document.getElementById("dataCheckoutQuarto").value;
    const emailUsuario = document.getElementById("emailUsuario").value; 
    const enderecoUsuario = document.getElementById("enderecoUsuario").value; 

    if (!tipoQuarto || !dataCheckin || !dataCheckout) {
        alert("Por favor, preencha todos os campos corretamente!");
        return;
    }

    const checkinDate = new Date(dataCheckin);
    const checkoutDate = new Date(dataCheckout);
    const diasEstadia = (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24);

    if (diasEstadia <= 0) {
        alert("A data de check-out deve ser posterior à data de check-in.");
        return;
    }

    const valorDiaria = parseFloat(tipoQuarto); 
    const valorTotal = valorDiaria * diasEstadia; 

    document.getElementById("valorTotalReserva").innerText = valorTotal.toFixed(2).replace(".", ",");

   
    const reserva = {
        nomeUsuario: usuario.nome,
        idUsuario: usuario.id,
        emailUsuario, 
        enderecoUsuario, 
        tipoQuarto,
        dataCheckin,
        dataCheckout,
        valorTotal
    };

    let reservas = JSON.parse(localStorage.getItem("reservas")) || [];
    reservas.push(reserva);
    localStorage.setItem("reservas", JSON.stringify(reservas));

    alert("Reserva cadastrada com sucesso!");
    document.getElementById("formReservaQuarto").reset();
    window.location.href = "indexhospede.html"; 
}

function calcularContas() {
    const nomeHospede = document.getElementById("nomeHospede").value.trim();
    const detalhesGastos = document.getElementById("detalhesGastos");
    detalhesGastos.innerHTML = "";

    if (!nomeHospede) {
        alert("Por favor, insira o nome do hóspede.");
        return;
    }

    const servicosHospede = JSON.parse(localStorage.getItem("servicosHospede")) || {};
    const frigobarHospede = JSON.parse(localStorage.getItem("frigobarHospede")) || {};
    const reservas = JSON.parse(localStorage.getItem("reservas")) || [];

    const servicos = servicosHospede[nomeHospede] || [];
    const frigobar = frigobarHospede[nomeHospede] || [];
    const reservaEncontrada = reservas.find(reserva => reserva.nomeUsuario === nomeHospede);

    let totalServicos = 0;
    servicos.forEach(servico => {
        detalhesGastos.innerHTML += `<li>Serviço: ${servico.nome} - R$ ${servico.preco.toFixed(2)}</li>`;
        totalServicos += servico.preco;
    });

    let totalFrigobar = 0;
    frigobar.forEach(item => {
        detalhesGastos.innerHTML += `<li>Frigobar: ${item.nome} - R$ ${item.preco.toFixed(2)}</li>`;
        totalFrigobar += item.preco;
    });

    let totalDiarias = 0;
    if (reservaEncontrada) {
        totalDiarias = reservaEncontrada.valorTotal || 0;
        detalhesGastos.innerHTML += `<li id="linhaDiarias">Diárias: R$ ${totalDiarias.toFixed(2)}</li>`; // Adiciona um ID à linha
    }

    const totalGeral = totalServicos + totalFrigobar + totalDiarias;
    document.getElementById("totalConta").innerText = `R$ ${totalGeral.toFixed(2)}`;

    const btnPagamento = document.getElementById("btnPagamento");
    const formPagamento = document.getElementById("formPagamento");
    if (totalGeral > 0) {
        btnPagamento.style.display = "none"; 
        formPagamento.style.display = "block"; 
    } else {
        btnPagamento.style.display = "none"; 
        formPagamento.style.display = "none"; 
    }
}

function pagar() {
    const formaPagamento = document.getElementById("formaPagamento").value;
    const senhaCartao = document.getElementById("senhaCartao").value;
    const nomeHospede = document.getElementById("nomeHospede").value.trim();
    const totalGeral = parseFloat(document.getElementById("totalConta").innerText.replace("R$ ", "").replace(",", "."));

    if (formaPagamento && senhaCartao) {
      
        document.getElementById("totalConta").innerText = `R$ 0,00`;

     
        const linhaDiarias = document.getElementById("linhaDiarias");
        if (linhaDiarias) {
            linhaDiarias.remove();
        }

     
        let reservas = JSON.parse(localStorage.getItem("reservas")) || [];
        const reservaIndex = reservas.findIndex(reserva => reserva.nomeUsuario === nomeHospede);

        if (reservaIndex !== -1) {
            reservas[reservaIndex].valorTotal = 0;
            localStorage.setItem("reservas", JSON.stringify(reservas));
        }

        alert("Pagamento realizado com sucesso!");
        document.getElementById("formPagamento").style.display = "none";
    } else {
        alert("Por favor, preencha todos os campos de pagamento.");
    }
}


function carregarHospedesParaCheckout() {
    const tabela = document.getElementById("listaCheckout").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";
    reservas.forEach((reserva, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = reserva.nomeUsuario;
        row.insertCell(1).innerText = reserva.dataCheckin;
        row.insertCell(2).innerText = reserva.dataCheckout;

        
        const valorTotal = reserva.valorTotal.toFixed(2);
        row.insertCell(3).innerText = `R$ ${valorTotal}`;

        const acaoCell = row.insertCell(4);
        const botaoVerConta = document.createElement("button");
        botaoVerConta.innerText = "Ver Conta";
        botaoVerConta.onclick = () => {
          
            window.location.href = `contas.html?nomeHospede=${encodeURIComponent(reserva.nomeUsuario)}`;
        };
        acaoCell.appendChild(botaoVerConta);
    });
}

function encerrarEstadia() {
    const nomeHospede = document.getElementById("nomeHospedeCheckout").value.trim();

    if (!nomeHospede) {
        alert("Por favor, insira o nome do hóspede.");
        return;
    }

  
    const index = reservas.findIndex(reserva => reserva.nomeUsuario === nomeHospede);
    if (index === -1) {
        alert("Hóspede não encontrado para check-out.");
        return;
    }

    
    reservas.splice(index, 1);
    localStorage.setItem("reservas", JSON.stringify(reservas));

    
    carregarHospedesParaCheckout();

    alert("Estadia encerrada com sucesso!");

    
    localStorage.setItem("totalConta", "0");
}

window.onload = carregarHospedesParaCheckout;

let produtosFrigobar = JSON.parse(localStorage.getItem("produtosFrigobar")) || [];

       
function adicionarProduto() {
    const nome = document.getElementById("nomeProduto").value;
    const id = document.getElementById("idProduto").value;
    const preco = parseFloat(document.getElementById("precoProduto").value);

   
    if (!nome || !id || isNaN(preco)) {
        alert("Por favor, preencha todos os campos corretamente!");
        return;
    }

  
    const produto = {id, nome, preco};
    produtosFrigobar.push(produto);

    localStorage.setItem("produtosFrigobar", JSON.stringify(produtosFrigobar));
    atualizarTabelaFrigobar();
    document.getElementById("formFrigobar").reset(); 
}


function atualizarTabelaFrigobar() {
    const tabela = document.getElementById("listaFrigobar").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";

    produtosFrigobar.forEach((produto, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = produto.id;
        row.insertCell(1).innerText = produto.nome;
        row.insertCell(2).innerText = `R$ ${produto.preco.toFixed(2)}`;

       
        const acaoCell = row.insertCell(3);
        const botaoRemover = document.createElement("button");
        botaoRemover.innerText = "Remover";
        botaoRemover.onclick = () => removerProduto(index);
        acaoCell.appendChild(botaoRemover);
    });
}


function removerProduto(index) {
    produtosFrigobar.splice(index, 1); 
    localStorage.setItem("produtosFrigobar", JSON.stringify(produtosFrigobar)); 
    atualizarTabelaFrigobar();
}

window.onload = atualizarTabelaFrigobar;

let servicos = JSON.parse(localStorage.getItem("servicos")) || [];

     
function adicionarServico() {
    const nome = document.getElementById("nomeServico").value;
    const id = document.getElementById("idServico").value;
    const preco = parseFloat(document.getElementById("precoServico").value);

  
    if (!nome || !id || isNaN(preco)) {
        alert("Por favor, preencha todos os campos corretamente!");
        return;
    }

    
    const servico = {id, nome, preco};
    servicos.push(servico);

  
    localStorage.setItem("servicos", JSON.stringify(servicos));
    atualizarTabelaServicos();
    document.getElementById("formServico").reset();
}


function atualizarTabelaServicos() {
    const tabela = document.getElementById("listaServicos").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";

    servicos.forEach((servico, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = servico.id;
        row.insertCell(1).innerText = servico.nome;
        row.insertCell(2).innerText = `R$ ${servico.preco.toFixed(2)}`;

     
        const acaoCell = row.insertCell(3);
        const botaoRemover = document.createElement("button");
        botaoRemover.innerText = "Remover";
        botaoRemover.onclick = () => removerServico(index);
        acaoCell.appendChild(botaoRemover);
    });
}


function removerServico(index) {
    servicos.splice(index, 1); 
    localStorage.setItem("servicos", JSON.stringify(servicos));
    atualizarTabelaServicos();
}


window.onload = atualizarTabelaServicos;

let comprasHospede = [];
let totalCompras = 0;

function carregarFrigobar() {
    const tabela = document.getElementById("listaFrigobar").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";
    produtosFrigobar.forEach((produto) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = produto.id;
        row.insertCell(1).innerText = produto.nome;
        row.insertCell(2).innerText = `R$ ${produto.preco.toFixed(2)}`;
        const acaoCell = row.insertCell(3);
        const botaoComprar = document.createElement("button");
        botaoComprar.innerText = "Comprar";
        botaoComprar.onclick = () => comprarItem(produto);
        acaoCell.appendChild(botaoComprar);
    });
}

function comprarItem(produto) {
    comprasHospede.push(produto);
    totalCompras += produto.preco;
    atualizarCompras();
}

function atualizarCompras() {
    const listaCompras = document.getElementById("listaCompras");
    const totalPagar = document.getElementById("totalPagar");

    listaCompras.innerHTML = "";
    comprasHospede.forEach(item => {
        const listItem = document.createElement("li");
        listItem.innerText = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
        listaCompras.appendChild(listItem);
    });
    totalPagar.innerText = `Total a Pagar: R$ ${totalCompras.toFixed(2)}`;
}

function finalizarConsumo() {
    const nomeHospede = prompt("Insira seu nome para finalizar o consumo:");
    if (!nomeHospede) return;

    let frigobarHospede = JSON.parse(localStorage.getItem("frigobarHospede")) || {};

    if (!frigobarHospede[nomeHospede]) {
        frigobarHospede[nomeHospede] = [];
    }

    frigobarHospede[nomeHospede] = frigobarHospede[nomeHospede].concat(comprasHospede);

    localStorage.setItem("frigobarHospede", JSON.stringify(frigobarHospede));
    alert("Consumo finalizado.");
}

window.onload = carregarFrigobar;

function carregarServicos() {
    const tabela = document.getElementById("listaServicos").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";
    servicos.forEach((servico) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = servico.id;
        row.insertCell(1).innerText = servico.nome;
        row.insertCell(2).innerText = `R$ ${servico.preco.toFixed(2)}`;
        const acaoCell = row.insertCell(3);
        const botaoComprar = document.createElement("button");
        botaoComprar.innerText = "Comprar";
        botaoComprar.onclick = () => comprarItem(servico);
        acaoCell.appendChild(botaoComprar);
    });
}

function comprarItem(servico) {
    comprasHospede.push(servico);
    totalCompras += servico.preco;
    atualizarCompras();
}

function atualizarCompras() {
    const listaCompras = document.getElementById("listaCompras");
    const totalPagar = document.getElementById("totalPagar");

    listaCompras.innerHTML = "";
    comprasHospede.forEach(item => {
        const listItem = document.createElement("li");
        listItem.innerText = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
        listaCompras.appendChild(listItem);
    });
    totalPagar.innerText = `Total a Pagar: R$ ${totalCompras.toFixed(2)}`;
}

function finalizarConsumo() {
    const nomeHospede = prompt("Insira seu nome para finalizar o consumo:");
    if (!nomeHospede) return;

    let servicosHospede = JSON.parse(localStorage.getItem("servicosHospede")) || {};

    if (!servicosHospede[nomeHospede]) {
        servicosHospede[nomeHospede] = [];
    }

    servicosHospede[nomeHospede] = servicosHospede[nomeHospede].concat(comprasHospede);

    localStorage.setItem("servicosHospede", JSON.stringify(servicosHospede));
    alert("Consumo finalizado.");
}

window.onload = carregarServicos;